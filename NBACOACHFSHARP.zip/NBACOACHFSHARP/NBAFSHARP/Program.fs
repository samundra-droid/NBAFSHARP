﻿// For more information see https://aka.ms/fsharp-console-apps
type Coach = {
    Name: string
    FormerPlayer: bool
}

type Stats = {
    Wins: int
    Losses: int
}

type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}

let teams = [
    { Name = "San Antonio Spurs"; Coach = { Name = "Gregg Popovich"; FormerPlayer = false }; Stats = { Wins = 2305; Losses = 1562 } }
    { Name = "Boston Celtics"; Coach = { Name = "Joe Mazzulla"; FormerPlayer = false }; Stats = { Wins = 3634; Losses = 2480 } }
    { Name = "Los Angeles Lakers"; Coach = { Name = "Darvin Ham"; FormerPlayer = true }; Stats = { Wins = 3550; Losses = 2454 } }
    { Name = "Utah Jazz"; Coach = { Name = "Will Hardy"; FormerPlayer = false }; Stats = { Wins = 2177; Losses = 1855 } }
    { Name = "Phoenix Suns"; Coach = { Name = "Frank Vogel"; FormerPlayer = false }; Stats = { Wins = 2429; Losses = 2096 } }
]

printfn "Teams:\n"
teams |> List.iter (fun team -> 
    printfn "Team: %s\n  Coach: %s\n  Former Player: %b\n  Wins: %d\n  Losses: %d\n" 
        team.Name team.Coach.Name team.Coach.FormerPlayer team.Stats.Wins team.Stats.Losses
)

let successfulTeams = teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)
printfn "Successful Teams:\n"
successfulTeams |> List.iter (fun team -> 
    printfn "Team: %s\n  Wins: %d\n  Losses: %d\n" 
        team.Name team.Stats.Wins team.Stats.Losses
)

let successPercentages = teams |> List.map (fun team -> 
    let wins = float team.Stats.Wins
    let losses = float team.Stats.Losses
    (team.Name, (wins / (wins + losses)) * 100.0)
)

printfn "Success Percentages:\n"
successPercentages |> List.iter (fun (name, percentage) -> 
    printfn "Team: %s\n  Success Percentage: %.2f%%\n" 
        name percentage
)
type Cuisine =
    | Korean
    | Turkish

type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks

type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float

let calculateBudget activity =
    match activity with
    | BoardGame -> 0.0
    | Chill -> 0.0
    | Movie movieType ->
        match movieType with
        | Regular -> 12.0
        | IMAX -> 17.0
        | DBOX -> 20.0
        | RegularWithSnacks -> 12.0 + 5.0
        | IMAXWithSnacks -> 17.0 + 5.0
        | DBOXWithSnacks -> 20.0 + 5.0
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70.0
        | Turkish -> 65.0
    | LongDrive (kilometres, fuelCostPerKm) -> float kilometres * fuelCostPerKm

// Example usage
let activities = [
    BoardGame
    Chill
    Movie Regular
    Movie IMAXWithSnacks
    Restaurant Korean
    LongDrive (100, 0.15)
]

let budgets = activities |> List.map calculateBudget


activities |> List.iteri (fun i activity -> 
    let budget = List.item i budgets
    match activity with
    | BoardGame -> printfn "Board Game: %.2f CAD" budget
    | Chill -> printfn "Chill: %.2f CAD" budget
    | Movie movieType -> 
        let movieTypeStr = 
            match movieType with
            | Regular -> "Regular"
            | IMAX -> "IMAX"
            | DBOX -> "DBOX"
            | RegularWithSnacks -> "Regular with Snacks"
            | IMAXWithSnacks -> "IMAX with Snacks"
            | DBOXWithSnacks -> "DBOX with Snacks"
        printfn "Movie (%s): %.2f CAD" movieTypeStr budget
    | Restaurant cuisine -> 
        let cuisineStr = 
            match cuisine with
            | Korean -> "Korean"
            | Turkish -> "Turkish"
        printfn "Restaurant (%s): %.2f CAD" cuisineStr budget
    | LongDrive (kilometres, fuelCostPerKm) -> 
        printfn "Long Drive: %.2f CAD" budget
)
